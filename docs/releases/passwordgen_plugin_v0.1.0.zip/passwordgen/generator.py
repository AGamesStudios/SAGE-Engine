
from secrets import choice
import string

DEFAULT_SETS = {
    'upper': string.ascii_uppercase,
    'lower': string.ascii_lowercase,
    'digits': string.digits,
    'symbols': '!@#$%^&*()-_=+[]{};:,.<>?/',
}

AMBIGUOUS = set('0O1lI|`'"{}[]()<>.,;:')

def build_charset(sets=('upper','lower','digits','symbols'), avoid_ambiguous=False, custom=None):
    chars = ''
    for s in sets:
        chars += DEFAULT_SETS.get(s, '')
    if custom:
        chars += ''.join(set(custom))
    if avoid_ambiguous:
        chars = ''.join([c for c in chars if c not in AMBIGUOUS])
    # ensure unique
    chars = ''.join(sorted(set(chars)))
    if not chars:
        raise ValueError('Empty charset')
    return chars

def generate(length=16, sets=('upper','lower','digits','symbols'), ensure_each=True, avoid_ambiguous=True, custom=None):
    charset = build_charset(sets, avoid_ambiguous, custom)
    pwd = []
    if ensure_each:
        seed = ''.join(DEFAULT_SETS[s][0] for s in sets if DEFAULT_SETS.get(s))
        for c in seed:
            if c in charset:
                pwd.append(c)
    while len(pwd) < length:
        pwd.append(choice(charset))
    # mix
    from random import shuffle
    shuffle(pwd)
    return ''.join(pwd[:length])
